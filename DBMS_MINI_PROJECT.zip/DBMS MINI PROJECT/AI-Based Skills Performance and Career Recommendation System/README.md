# AI-Based Skills, Performance and Career Recommendation System

A complete Flask + PostgreSQL full-stack application that uses the exact database schema from the provided document and generates career recommendations from stored skill, career, course, assessment, and recommendation data.

## Features

- Student profile form with name, email, CGPA, department, attendance, year, and skill levels
- PostgreSQL integration using `psycopg2`
- Inserts into `student` and `student_skill`
- Recommendation engine that reads from `career_path` and `career_skill`
- Match score calculation from skill coverage, skill level satisfaction, CGPA eligibility, and department match
- Recommendation persistence in `recommendation`
- Results page with matched skills, missing skills, and explanation text
- Clean modular backend structure

## Project Structure

```text
AI-Based-Career-System/
├── backend/
│   ├── app.py
│   ├── config.py
│   ├── models/
│   │   ├── db.py
│   │   ├── recommendation_model.py
│   │   └── student_model.py
│   ├── routes/
│   │   ├── recommendation_routes.py
│   │   └── student_routes.py
│   └── services/
│       └── recommendation_engine.py
├── database/
│   └── Career_recommendation.sql
├── frontend/
│   ├── static/
│   │   ├── css/style.css
│   │   └── js/script.js
│   └── templates/
│       ├── base.html
│       ├── index.html
│       ├── result.html
│       └── student_form.html
├── requirements.txt
├── README.md
└── run.py
```

## Setup

1. Create a PostgreSQL database.
2. Import the SQL dump:
   ```bash
   psql -U postgres -d career_recommendation -f database/Career_recommendation.sql
   ```
3. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate
   ```
   On Windows:
   ```bash
   venv\Scriptsctivate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Set environment variables if needed:
   ```bash
   export DB_HOST=localhost
   export DB_PORT=5432
   export DB_NAME=career_recommendation
   export DB_USER=postgres
   export DB_PASSWORD=postgres
   export SECRET_KEY=career-system-secret-key
   ```
6. Run the application:
   ```bash
   python run.py
   ```
7. Open `http://127.0.0.1:5000` in your browser.

## Recommendation Logic

For every row in `career_path`:

1. Fetch required skills from `career_skill`
2. Compare them with the current student's `student_skill`
3. Evaluate skill presence and level satisfaction
4. Check CGPA requirement from `career_path.cgpa_required`
5. Check department match with `career_path.preferred_dept`
6. Compute final match score on a 0-100 scale
7. Store results in `recommendation`

### Match Score Formula

- 40% skill match percentage
- 30% required level satisfaction
- 20% CGPA eligibility
- 10% department match

## Notes

- The `admin` table is kept exactly as defined but not exposed in the UI.
- All required schema tables are preserved: `admin`, `student`, `skill`, `student_skill`, `career_path`, `career_skill`, `course`, `enrolls_in`, `assessment`, and `recommendation`.
- The SQL file is included exactly for database import and should be loaded before running the app.
