from flask import Flask
from backend.config import Config
from backend.routes.student_routes import student_bp
from backend.routes.recommendation_routes import recommendation_bp
from backend.routes.admin_routes import admin_bp


def create_app():
    app = Flask(
        __name__,
        template_folder='../frontend/templates',
        static_folder='../frontend/static'
    )
    app.config.from_object(Config)
    app.secret_key = app.config['SECRET_KEY']
    app.register_blueprint(student_bp)
    app.register_blueprint(recommendation_bp)
    app.register_blueprint(admin_bp)
    return app
