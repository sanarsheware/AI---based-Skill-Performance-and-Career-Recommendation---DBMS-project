from backend.models.db import get_connection
import psycopg2

class AdminModel:
    @staticmethod
    def authenticate(email, password):
        try:
            with get_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        "SELECT admin_id, name, email FROM public.admin WHERE email = %s AND password = %s",
                        (email, password)
                    )
                    return cur.fetchone()
        except psycopg2.Error as e:
            print(f"Database error during admin auth: {e}")
            return None

    @staticmethod
    def get_dashboard_stats():
        stats = {
            'total_students': 0,
            'total_recommendations': 0,
            'top_career': 'None',
            'recent_students': []
        }
        try:
            with get_connection() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT COUNT(*) as count FROM public.student")
                    row = cur.fetchone()
                    if row: stats['total_students'] = row['count']

                    cur.execute("SELECT COUNT(*) as count FROM public.recommendation")
                    row = cur.fetchone()
                    if row: stats['total_recommendations'] = row['count']

                    cur.execute("""
                        SELECT c.description, COUNT(r.recommendation_id) as rec_count
                        FROM public.recommendation r
                        JOIN public.career_path c ON r.career_id = c.career_id
                        GROUP BY c.description
                        ORDER BY rec_count DESC
                        LIMIT 1
                    """)
                    row = cur.fetchone()
                    if row: stats['top_career'] = row['description']

                    cur.execute("""
                        SELECT name, email, dept, cgpa 
                        FROM public.student 
                        ORDER BY stud_id DESC 
                        LIMIT 5
                    """)
                    stats['recent_students'] = cur.fetchall()
        except psycopg2.Error as e:
            print(f"Database error fetching stats: {e}")
            
        return stats
