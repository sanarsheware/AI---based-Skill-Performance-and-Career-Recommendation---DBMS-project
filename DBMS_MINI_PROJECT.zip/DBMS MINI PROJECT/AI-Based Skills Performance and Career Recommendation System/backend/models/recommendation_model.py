from backend.models.db import get_connection


class RecommendationModel:
    @staticmethod
    def get_career_paths_with_skills():
        query = """
            SELECT
                cp.career_id,
                cp.description,
                cp.cgpa_required,
                cp.preferred_dept,
                cs.id AS career_skill_id,
                cs.skill_id,
                cs.required_level,
                sk.skill_name
            FROM career_path cp
            LEFT JOIN career_skill cs ON cp.career_id = cs.career_id
            LEFT JOIN skill sk ON cs.skill_id = sk.skill_id
            ORDER BY cp.career_id, sk.skill_name;
        """
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query)
                return cur.fetchall()

    @staticmethod
    def save_recommendation(stud_id, career_id, match_score):
        query = """
            INSERT INTO recommendation (stud_id, career_id, match_score)
            VALUES (%s, %s, %s)
            ON CONFLICT (stud_id, career_id)
            DO UPDATE SET match_score = EXCLUDED.match_score
            RETURNING recommendation_id, stud_id, career_id, match_score;
        """
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (stud_id, career_id, match_score))
                row = cur.fetchone()
            conn.commit()
        return row

    @staticmethod
    def get_recommendations_for_student(stud_id):
        query = """
            SELECT r.recommendation_id, r.stud_id, r.career_id, r.match_score, cp.description,
                   cp.cgpa_required, cp.preferred_dept
            FROM recommendation r
            JOIN career_path cp ON r.career_id = cp.career_id
            WHERE r.stud_id = %s
            ORDER BY r.match_score DESC, cp.description ASC;
        """
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (stud_id,))
                return cur.fetchall()
