from backend.models.db import get_connection


class StudentModel:
    @staticmethod
    def create_student(name, email, year, cgpa, dept, attendance):
        query = """
            INSERT INTO student (name, email, year, cgpa, dept, attendance)
            VALUES (%s, %s, %s, %s, %s, %s)
            RETURNING stud_id, name, email, year, cgpa, dept, attendance;
        """
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (name, email, year, cgpa, dept, attendance))
                student = cur.fetchone()
            conn.commit()
        return student

    @staticmethod
    def create_student_skill(stud_id, skill_id, skill_level):
        query = """
            INSERT INTO student_skill (stud_id, skill_id, skill_level)
            VALUES (%s, %s, %s)
            ON CONFLICT (stud_id, skill_id)
            DO UPDATE SET skill_level = EXCLUDED.skill_level
            RETURNING id, stud_id, skill_id, skill_level;
        """
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query, (stud_id, skill_id, skill_level))
                row = cur.fetchone()
            conn.commit()
        return row

    @staticmethod
    def get_all_skills():
        query = "SELECT skill_id, skill_name FROM skill ORDER BY skill_name;"
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(query)
                return cur.fetchall()

    @staticmethod
    def get_student_with_skills(stud_id):
        student_query = """
            SELECT stud_id, name, email, year, cgpa, dept, attendance
            FROM student
            WHERE stud_id = %s;
        """
        skill_query = """
            SELECT ss.id, ss.skill_id, sk.skill_name, ss.skill_level
            FROM student_skill ss
            JOIN skill sk ON ss.skill_id = sk.skill_id
            WHERE ss.stud_id = %s
            ORDER BY sk.skill_name;
        """
        with get_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(student_query, (stud_id,))
                student = cur.fetchone()
                cur.execute(skill_query, (stud_id,))
                skills = cur.fetchall()
        return student, skills
