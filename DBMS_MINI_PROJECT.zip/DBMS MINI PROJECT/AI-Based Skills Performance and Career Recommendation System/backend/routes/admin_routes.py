from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from backend.models.admin_model import AdminModel

admin_bp = Blueprint('admin_bp', __name__, url_prefix='/admin')

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    if 'admin_id' in session:
        return redirect(url_for('admin_bp.dashboard'))
        
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()
        
        if not email or not password:
            flash('Email and password are required.', 'error')
            return redirect(url_for('admin_bp.login'))
            
        admin = AdminModel.authenticate(email, password)
        if admin:
            session['admin_id'] = admin['admin_id']
            session['admin_name'] = admin['name']
            flash('Logged in successfully.', 'success')
            return redirect(url_for('admin_bp.dashboard'))
        else:
            flash('Invalid email or password.', 'error')
            return redirect(url_for('admin_bp.login'))
            
    return render_template('admin/login.html')

@admin_bp.route('/dashboard')
def dashboard():
    if 'admin_id' not in session:
        flash('Please log in to access the dashboard.', 'error')
        return redirect(url_for('admin_bp.login'))
        
    stats = AdminModel.get_dashboard_stats()
    return render_template('admin/dashboard.html', admin_name=session.get('admin_name'), stats=stats)

@admin_bp.route('/logout')
def logout():
    session.pop('admin_id', None)
    session.pop('admin_name', None)
    flash('Logged out successfully.', 'success')
    return redirect(url_for('admin_bp.login'))
