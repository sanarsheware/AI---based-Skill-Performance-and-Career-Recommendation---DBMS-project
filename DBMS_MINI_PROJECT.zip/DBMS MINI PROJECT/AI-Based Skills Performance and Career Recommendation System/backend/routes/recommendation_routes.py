from flask import Blueprint, jsonify
from backend.models.student_model import StudentModel
from backend.models.recommendation_model import RecommendationModel

recommendation_bp = Blueprint('recommendation_bp', __name__)


@recommendation_bp.route('/api/student/<int:stud_id>/profile', methods=['GET'])
def student_profile(stud_id):
    student, skills = StudentModel.get_student_with_skills(stud_id)
    recommendations = RecommendationModel.get_recommendations_for_student(stud_id)
    return jsonify({
        'student': student,
        'skills': skills,
        'recommendations': recommendations
    })
