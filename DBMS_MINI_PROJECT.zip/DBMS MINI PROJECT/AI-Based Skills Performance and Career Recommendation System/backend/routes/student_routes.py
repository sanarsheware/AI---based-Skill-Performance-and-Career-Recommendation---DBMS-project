from flask import Blueprint, render_template, request, redirect, url_for, flash
from backend.models.student_model import StudentModel
from backend.services.recommendation_engine import generate_recommendations

student_bp = Blueprint('student_bp', __name__)


@student_bp.route('/')
def index():
    return render_template('index.html')


@student_bp.route('/student/form', methods=['GET'])
def student_form():
    skills = StudentModel.get_all_skills()
    return render_template('student_form.html', skills=skills)


@student_bp.route('/student/submit', methods=['POST'])
def submit_student():
    try:
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip()
        cgpa = float(request.form.get('cgpa', 0))
        dept = request.form.get('department', '').strip()
        attendance = float(request.form.get('attendance', 0))
        year = int(request.form.get('year', 1))

        if not name or not email or not dept:
            raise ValueError('Name, email, and department are required.')

        student = StudentModel.create_student(name, email, year, cgpa, dept, attendance)
        selected_skills = []

        for skill in StudentModel.get_all_skills():
            field_name = f"skill_{skill['skill_id']}"
            skill_level = request.form.get(field_name)
            if skill_level:
                StudentModel.create_student_skill(student['stud_id'], skill['skill_id'], int(skill_level))
                selected_skills.append({
                    'skill_id': skill['skill_id'],
                    'skill_name': skill['skill_name'],
                    'skill_level': int(skill_level)
                })

        recommendations = generate_recommendations(student, selected_skills)
        return render_template('result.html', student=student, recommendations=recommendations)
    except Exception as exc:
        flash(str(exc), 'error')
        return redirect(url_for('student_bp.student_form'))
