from collections import defaultdict
from backend.models.recommendation_model import RecommendationModel


def _normalize(text):
    return (text or '').strip().lower()


def generate_recommendations(student, student_skills):
    student_skill_map = {skill['skill_id']: skill for skill in student_skills}
    grouped = defaultdict(list)

    for row in RecommendationModel.get_career_paths_with_skills():
        grouped[row['career_id']].append(row)

    recommendations = []

    for career_id, rows in grouped.items():
        first = rows[0]
        required_skills = [row for row in rows if row['skill_id'] is not None]
        total_required = len(required_skills)
        matched_skills = []
        missing_skills = []
        level_points = 0

        for required in required_skills:
            student_skill = student_skill_map.get(required['skill_id'])
            if student_skill:
                matched_skills.append({
                    'skill_name': required['skill_name'],
                    'student_level': student_skill['skill_level'],
                    'required_level': required['required_level'],
                    'meets_requirement': student_skill['skill_level'] >= required['required_level']
                })
                level_points += min(student_skill['skill_level'], required['required_level']) / required['required_level']
            else:
                missing_skills.append({
                    'skill_name': required['skill_name'],
                    'required_level': required['required_level']
                })

        skill_presence_pct = (len(matched_skills) / total_required) * 100 if total_required else 100
        level_satisfaction_pct = (level_points / total_required) * 100 if total_required else 100
        cgpa_ok = student['cgpa'] is not None and first['cgpa_required'] is not None and student['cgpa'] >= first['cgpa_required']
        cgpa_pct = 100 if cgpa_ok else max(0, (student['cgpa'] / first['cgpa_required']) * 100) if first['cgpa_required'] else 100
        dept_match = _normalize(student['dept']) == _normalize(first['preferred_dept'])
        dept_pct = 100 if dept_match else 40

        match_score = round((skill_presence_pct * 0.4) + (level_satisfaction_pct * 0.3) + (cgpa_pct * 0.2) + (dept_pct * 0.1), 2)
        match_score = max(0, min(100, match_score))

        RecommendationModel.save_recommendation(student['stud_id'], career_id, match_score)

        recommendations.append({
            'career_id': career_id,
            'career_name': first['description'],
            'match_score': match_score,
            'cgpa_required': first['cgpa_required'],
            'preferred_dept': first['preferred_dept'],
            'cgpa_eligible': cgpa_ok,
            'department_match': dept_match,
            'matched_skills': matched_skills,
            'missing_skills': missing_skills,
            'explanation': build_explanation(first['description'], matched_skills, missing_skills, cgpa_ok, dept_match)
        })

    recommendations.sort(key=lambda item: (-item['match_score'], item['career_name']))
    return recommendations


def build_explanation(career_name, matched_skills, missing_skills, cgpa_ok, dept_match):
    matched_names = ', '.join(
        f"{item['skill_name']} ({item['student_level']}/{item['required_level']})" for item in matched_skills
    ) or 'No direct required skills matched yet'
    missing_names = ', '.join(
        f"{item['skill_name']} (needs {item['required_level']})" for item in missing_skills
    ) or 'No missing required skills'
    cgpa_text = 'meets' if cgpa_ok else 'does not meet'
    dept_text = 'matches' if dept_match else 'does not match'
    return (
        f"For {career_name}, matched skills: {matched_names}. "
        f"Missing skills: {missing_names}. "
        f"Student {cgpa_text} the CGPA requirement and {dept_text} the preferred department."
    )
