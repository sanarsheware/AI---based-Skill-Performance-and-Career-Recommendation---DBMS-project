--
-- PostgreSQL database dump
--
--\resbtrict bM3EbbGYXOdSyOEdSxXKd1ZE9s2mpvvsxYdLSOR0psFvsvCXf1VnwQnl2EPiYkv
-- Dumped from database version 18.2
-- Dumped by pg_dump version 18.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;
SET default_tablespace = '';
SET default_table_access_method = heap;

-- Name: admin; Type: TABLE; Schema: public; Owner: nukul
CREATE TABLE public.admin (
    admin_id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    password character varying(8) NOT NULL,
    CONSTRAINT admin_password_check CHECK ((length((password)::text) = 8))
);
ALTER TABLE public.admin OWNER TO nukul;

CREATE SEQUENCE public.admin_admin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER SEQUENCE public.admin_admin_id_seq OWNER TO nukul;
ALTER SEQUENCE public.admin_admin_id_seq OWNED BY public.admin.admin_id;

-- Name: assessment; Type: TABLE; Schema: public; Owner: nukul
CREATE TABLE public.assessment (
    test_id integer NOT NULL,
    test_name text NOT NULL,
    skill_id integer NOT NULL,
    max_score integer,
    CONSTRAINT assessment_max_score_check CHECK ((max_score > 0))
);
ALTER TABLE public.assessment OWNER TO nukul;

CREATE SEQUENCE public.assessment_test_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER SEQUENCE public.assessment_test_id_seq OWNER TO nukul;
ALTER SEQUENCE public.assessment_test_id_seq OWNED BY public.assessment.test_id;

-- Name: career_path; Type: TABLE; Schema: public; Owner: nukul
CREATE TABLE public.career_path (
    career_id integer NOT NULL,
    description text NOT NULL,
    cgpa_required double precision,
    preferred_dept text NOT NULL,
    CONSTRAINT career_path_cgpa_required_check CHECK (((cgpa_required >= (0)::double precision) AND (cgpa_required <= (10)::double precision)))
);
ALTER TABLE public.career_path OWNER TO nukul;

CREATE SEQUENCE public.career_path_career_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER SEQUENCE public.career_path_career_id_seq OWNER TO nukul;
ALTER SEQUENCE public.career_path_career_id_seq OWNED BY public.career_path.career_id;

-- Name: career_skill; Type: TABLE; Schema: public; Owner: nukul
CREATE TABLE public.career_skill (
    id integer NOT NULL,
    career_id integer NOT NULL,
    skill_id integer NOT NULL,
    required_level integer,
    CONSTRAINT career_skill_required_level_check CHECK (((required_level >= 1) AND (required_level <= 10)))
);
ALTER TABLE public.career_skill OWNER TO nukul;

CREATE SEQUENCE public.career_skill_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER SEQUENCE public.career_skill_id_seq OWNER TO nukul;
ALTER SEQUENCE public.career_skill_id_seq OWNED BY public.career_skill.id;

-- Name: course; Type: TABLE; Schema: public; Owner: nukul
CREATE TABLE public.course (
    course_id integer NOT NULL,
    course_name text NOT NULL,
    platform text NOT NULL,
    duration integer,
    CONSTRAINT course_duration_check CHECK ((duration > 0))
);
ALTER TABLE public.course OWNER TO nukul;

CREATE SEQUENCE public.course_course_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER SEQUENCE public.course_course_id_seq OWNER TO nukul;
ALTER SEQUENCE public.course_course_id_seq OWNED BY public.course.course_id;

-- Name: enrolls_in; Type: TABLE; Schema: public; Owner: nukul
CREATE TABLE public.enrolls_in (
    id integer NOT NULL,
    stud_id integer NOT NULL,
    course_id integer NOT NULL
);
ALTER TABLE public.enrolls_in OWNER TO nukul;

CREATE SEQUENCE public.enrolls_in_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER SEQUENCE public.enrolls_in_id_seq OWNER TO nukul;
ALTER SEQUENCE public.enrolls_in_id_seq OWNED BY public.enrolls_in.id;

-- Name: recommendation; Type: TABLE; Schema: public; Owner: nukul
CREATE TABLE public.recommendation (
    recommendation_id integer NOT NULL,
    stud_id integer NOT NULL,
    career_id integer NOT NULL,
    match_score double precision,
    CONSTRAINT recommendation_match_score_check CHECK (((match_score >= (0)::double precision) AND (match_score <= (100)::double precision)))
);
ALTER TABLE public.recommendation OWNER TO nukul;

CREATE SEQUENCE public.recommendation_recommendation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER SEQUENCE public.recommendation_recommendation_id_seq OWNER TO nukul;
ALTER SEQUENCE public.recommendation_recommendation_id_seq OWNED BY public.recommendation.recommendation_id;

-- Name: skill; Type: TABLE; Schema: public; Owner: nukul
CREATE TABLE public.skill (
    skill_id integer NOT NULL,
    skill_name text NOT NULL
);
ALTER TABLE public.skill OWNER TO nukul;

CREATE SEQUENCE public.skill_skill_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER SEQUENCE public.skill_skill_id_seq OWNER TO nukul;
ALTER SEQUENCE public.skill_skill_id_seq OWNED BY public.skill.skill_id;

-- Name: student; Type: TABLE; Schema: public; Owner: nukul
CREATE TABLE public.student (
    stud_id integer NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    year integer,
    cgpa double precision,
    dept text NOT NULL,
    attendance double precision,
    CONSTRAINT student_attendance_check CHECK (((attendance >= (0)::double precision) AND (attendance <= (100)::double precision))),
    CONSTRAINT student_cgpa_check CHECK (((cgpa >= (0)::double precision) AND (cgpa <= (10)::double precision))),
    CONSTRAINT student_year_check CHECK (((year >= 1) AND (year <= 4)))
);
ALTER TABLE public.student OWNER TO nukul;

-- Name: student_skill; Type: TABLE; Schema: public; Owner: nukul
CREATE TABLE public.student_skill (
    id integer NOT NULL,
    stud_id integer NOT NULL,
    skill_id integer NOT NULL,
    skill_level integer,
    CONSTRAINT student_skill_skill_level_check CHECK (((skill_level >= 1) AND (skill_level <= 10)))
);
ALTER TABLE public.student_skill OWNER TO nukul;

CREATE SEQUENCE public.student_skill_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER SEQUENCE public.student_skill_id_seq OWNER TO nukul;
ALTER SEQUENCE public.student_skill_id_seq OWNED BY public.student_skill.id;

CREATE VIEW public.student_skill_view AS
 SELECT s.name,
    sk.skill_name,
    ss.skill_level
   FROM ((public.student s
     JOIN public.student_skill ss ON ((s.stud_id = ss.stud_id)))
     JOIN public.skill sk ON ((ss.skill_id = sk.skill_id)));
ALTER VIEW public.student_skill_view OWNER TO u0_a369;

CREATE SEQUENCE public.student_stud_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;
ALTER SEQUENCE public.student_stud_id_seq OWNER TO nukul;
ALTER SEQUENCE public.student_stud_id_seq OWNED BY public.student.stud_id;

CREATE VIEW public.student_view AS
 SELECT name,
    cgpa,
    dept
   FROM public.student;
ALTER VIEW public.student_view OWNER TO u0_a369;

ALTER TABLE ONLY public.admin ALTER COLUMN admin_id SET DEFAULT nextval('public.admin_admin_id_seq'::regclass);
ALTER TABLE ONLY public.assessment ALTER COLUMN test_id SET DEFAULT nextval('public.assessment_test_id_seq'::regclass);
ALTER TABLE ONLY public.career_path ALTER COLUMN career_id SET DEFAULT nextval('public.career_path_career_id_seq'::regclass);
ALTER TABLE ONLY public.career_skill ALTER COLUMN id SET DEFAULT nextval('public.career_skill_id_seq'::regclass);
ALTER TABLE ONLY public.course ALTER COLUMN course_id SET DEFAULT nextval('public.course_course_id_seq'::regclass);
ALTER TABLE ONLY public.enrolls_in ALTER COLUMN id SET DEFAULT nextval('public.enrolls_in_id_seq'::regclass);
ALTER TABLE ONLY public.recommendation ALTER COLUMN recommendation_id SET DEFAULT nextval('public.recommendation_recommendation_id_seq'::regclass);
ALTER TABLE ONLY public.skill ALTER COLUMN skill_id SET DEFAULT nextval('public.skill_skill_id_seq'::regclass);
ALTER TABLE ONLY public.student ALTER COLUMN stud_id SET DEFAULT nextval('public.student_stud_id_seq'::regclass);
ALTER TABLE ONLY public.student_skill ALTER COLUMN id SET DEFAULT nextval('public.student_skill_id_seq'::regclass);

COPY public.admin (admin_id, name, email, password) FROM stdin;
1	Nukul	nukul@gmail.com	nukul123
2	Sana	sana@gmail.com	sana1234
3	Kuber	kuber@gmail.com	kuber123
4	Aarav	aarav@gmail.com	aarav123
5	Meera	meera@gmail.com	meera123
\.

COPY public.assessment (test_id, test_name, skill_id, max_score) FROM stdin;
1	Python Test	1	100
2	C++ Test	2	100
3	Communication Test	3	50
4	Cyber Test	4	100
5	Data Test	5	100
\.

COPY public.career_path (career_id, description, cgpa_required, preferred_dept) FROM stdin;
1	Software Engineer	7	CSE
2	Cybersecurity Analyst	7.5	CSE
3	Data Analyst	7	IT
4	Network Engineer	6.5	ETC
5	AI Engineer	8	CSE (DS)
\.

COPY public.career_skill (id, career_id, skill_id, required_level) FROM stdin;
1	1	1	7
2	1	2	6
3	2	4	8
4	3	5	7
5	3	3	6
6	4	2	6
7	5	1	9
\.

COPY public.course (course_id, course_name, platform, duration) FROM stdin;
1	Python Basics	Coursera	30
2	C++ Mastery	Udemy	40
3	Cybersecurity Intro	edX	25
4	Data Analysis	Coursera	35
5	Communication Skills	Udemy	20
\.

COPY public.enrolls_in (id, stud_id, course_id) FROM stdin;
1	1	1
2	2	4
3	3	3
4	4	2
5	5	5
\.

COPY public.recommendation (recommendation_id, stud_id, career_id, match_score) FROM stdin;
1	1	1	85
2	2	3	78
3	3	5	92
4	4	4	65
5	5	1	80
\.

COPY public.skill (skill_id, skill_name) FROM stdin;
1	Python
2	C++
3	Communication
4	Cybersecurity
5	Data Analysis
\.

COPY public.student (stud_id, name, email, year, cgpa, dept, attendance) FROM stdin;
2	Anjali	anjali@gmail.com	3	7.6	IT	78
3	Kabir	kabir@gmail.com	1	9.1	CSE (DS)	90
4	Sneha	sneha@gmail.com	4	6.9	Civil	72
5	Armaan	armaan@gmail.com	2	7.8	Mechanical	80
1	Rohit	rohit@gmail.com	2	9	CSE	85
\.

COPY public.student_skill (id, stud_id, skill_id, skill_level) FROM stdin;
1	1	1	8
2	1	2	7
3	2	3	6
4	3	1	9
5	3	4	8
6	4	2	5
7	5	5	8
\.

SELECT pg_catalog.setval('public.admin_admin_id_seq', 5, true);
SELECT pg_catalog.setval('public.assessment_test_id_seq', 5, true);
SELECT pg_catalog.setval('public.career_path_career_id_seq', 5, true);
SELECT pg_catalog.setval('public.career_skill_id_seq', 7, true);
SELECT pg_catalog.setval('public.course_course_id_seq', 5, true);
SELECT pg_catalog.setval('public.enrolls_in_id_seq', 5, true);
SELECT pg_catalog.setval('public.recommendation_recommendation_id_seq', 5, true);
SELECT pg_catalog.setval('public.skill_skill_id_seq', 5, true);
SELECT pg_catalog.setval('public.student_skill_id_seq', 7, true);
SELECT pg_catalog.setval('public.student_stud_id_seq', 5, true);

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_email_key UNIQUE (email);
ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (admin_id);
ALTER TABLE ONLY public.assessment
    ADD CONSTRAINT assessment_pkey PRIMARY KEY (test_id);
ALTER TABLE ONLY public.career_path
    ADD CONSTRAINT career_path_pkey PRIMARY KEY (career_id);
ALTER TABLE ONLY public.career_skill
    ADD CONSTRAINT career_skill_career_id_skill_id_key UNIQUE (career_id, skill_id);
ALTER TABLE ONLY public.career_skill
    ADD CONSTRAINT career_skill_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_pkey PRIMARY KEY (course_id);
ALTER TABLE ONLY public.enrolls_in
    ADD CONSTRAINT enrolls_in_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.enrolls_in
    ADD CONSTRAINT enrolls_in_stud_id_course_id_key UNIQUE (stud_id, course_id);
ALTER TABLE ONLY public.recommendation
    ADD CONSTRAINT recommendation_pkey PRIMARY KEY (recommendation_id);
ALTER TABLE ONLY public.recommendation
    ADD CONSTRAINT recommendation_stud_id_career_id_key UNIQUE (stud_id, career_id);
ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_pkey PRIMARY KEY (skill_id);
ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_skill_name_key UNIQUE (skill_name);
ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_email_key UNIQUE (email);
ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_pkey PRIMARY KEY (stud_id);
ALTER TABLE ONLY public.student_skill
    ADD CONSTRAINT student_skill_pkey PRIMARY KEY (id);
ALTER TABLE ONLY public.student_skill
    ADD CONSTRAINT student_skill_stud_id_skill_id_key UNIQUE (stud_id, skill_id);
ALTER TABLE ONLY public.assessment
    ADD CONSTRAINT assessment_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES public.skill(skill_id) ON DELETE CASCADE;
ALTER TABLE ONLY public.career_skill
    ADD CONSTRAINT career_skill_career_id_fkey FOREIGN KEY (career_id) REFERENCES public.career_path(career_id) ON DELETE CASCADE;
ALTER TABLE ONLY public.career_skill
    ADD CONSTRAINT career_skill_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES public.skill(skill_id) ON DELETE CASCADE;
ALTER TABLE ONLY public.enrolls_in
    ADD CONSTRAINT enrolls_in_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(course_id) ON DELETE CASCADE;
ALTER TABLE ONLY public.enrolls_in
    ADD CONSTRAINT enrolls_in_stud_id_fkey FOREIGN KEY (stud_id) REFERENCES public.student(stud_id) ON DELETE CASCADE;
ALTER TABLE ONLY public.recommendation
    ADD CONSTRAINT recommendation_career_id_fkey FOREIGN KEY (career_id) REFERENCES public.career_path(career_id) ON DELETE CASCADE;
ALTER TABLE ONLY public.recommendation
    ADD CONSTRAINT recommendation_stud_id_fkey FOREIGN KEY (stud_id) REFERENCES public.student(stud_id) ON DELETE CASCADE;
ALTER TABLE ONLY public.student_skill
    ADD CONSTRAINT student_skill_skill_id_fkey FOREIGN KEY (skill_id) REFERENCES public.skill(skill_id) ON DELETE CASCADE;
ALTER TABLE ONLY public.student_skill
    ADD CONSTRAINT student_skill_stud_id_fkey FOREIGN KEY (stud_id) REFERENCES public.student(stud_id) ON DELETE CASCADE;

-- PostgreSQL database dump complete
--\unrestrict bM3EbbGYXOdSyOEdSxXKd1ZE9s2mpvvsxYdLSOR0psFvsvCXf1VnwQnl2EPiYkv