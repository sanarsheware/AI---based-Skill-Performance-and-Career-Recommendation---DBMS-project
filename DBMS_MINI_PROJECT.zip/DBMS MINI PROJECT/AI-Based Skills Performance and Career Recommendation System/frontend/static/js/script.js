(() => {
    const button = document.querySelector('[data-theme-toggle]');
    const root = document.documentElement;
    let currentTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';

    const applyTheme = (theme) => {
        root.setAttribute('data-theme', theme);
        if (button) {
            button.textContent = theme === 'dark' ? '☀' : '☾';
            button.setAttribute('aria-label', `Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`);
        }
    };

    applyTheme(currentTheme);

    button?.addEventListener('click', () => {
        currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
        applyTheme(currentTheme);
    });
})();
